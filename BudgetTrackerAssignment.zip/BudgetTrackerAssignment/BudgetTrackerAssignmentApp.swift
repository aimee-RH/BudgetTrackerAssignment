//
//  BudgetTrackerAssignmentApp.swift
//  BudgetTrackerAssignment
//
//  Created by Rik Roy on 8/22/25.
//

import SwiftUI

@main
struct BudgetTrackerAssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
